// ──────────────────────────────────────────────────────────
        //  DATA
        // ──────────────────────────────────────────────────────────

        const ALL_SCENARIOS = ['Actual', 'Forecast', 'Budget', 'Worst Case', 'Best Case'];
        const YEARS = ['2021', '2022', '2023', '2024', '2025'];

        // Table definitions with their line items
        const TABLES = {
            income: {
                name: 'Income Statement',
                lineItems: [
                    'Net income / (loss)',
                    'Result before income taxes',
                    'Operating income / (loss)',
                    'Financial and neutral result',
                    'Other taxes',
                    'Taxes on income'
                ]
            },
            balance: {
                name: 'Balance Sheet',
                lineItems: [
                    'Total Assets',
                    'Total Liabilities',
                    'Total Equity',
                    'Current Assets',
                    'Current Liabilities',
                    'Retained Earnings'
                ]
            },
            cashflow: {
                name: 'Cash Flow',
                lineItems: [
                    'Operating Cash Flow',
                    'Investing Cash Flow',
                    'Financing Cash Flow',
                    'Net Change in Cash',
                    'Free Cash Flow',
                    'Dividends Paid'
                ]
            }
        };

        // Generate financial data for each table and scenario/year
        function generateData() {
            const data = {};
            // Base values for each table (for 2025 Actual)
            const base2025 = {
                income: {
                    'Net income / (loss)': 82182,
                    'Result before income taxes': 84250,
                    'Operating income / (loss)': 90197,
                    'Financial and neutral result': -5778,
                    'Other taxes': -169,
                    'Taxes on income': -2068
                },
                balance: {
                    'Total Assets': 1200000,
                    'Total Liabilities': 720000,
                    'Total Equity': 480000,
                    'Current Assets': 350000,
                    'Current Liabilities': 280000,
                    'Retained Earnings': 320000
                },
                cashflow: {
                    'Operating Cash Flow': 95000,
                    'Investing Cash Flow': -45000,
                    'Financing Cash Flow': -20000,
                    'Net Change in Cash': 30000,
                    'Free Cash Flow': 50000,
                    'Dividends Paid': -15000
                }
            };

            // Growth rates for each line item (per year, for Actual)
            const growthRates = {
                income: {
                    'Net income / (loss)': [0.04, 0.06, 0.05, 0.07, 0.04],
                    'Result before income taxes': [0.03, 0.07, 0.04, 0.06, 0.05],
                    'Operating income / (loss)': [0.05, 0.05, 0.06, 0.04, 0.06],
                    'Financial and neutral result': [-0.02, 0.01, -0.01, 0.02, -0.01],
                    'Other taxes': [0.02, -0.01, 0.03, 0.01, -0.02],
                    'Taxes on income': [0.01, 0.03, 0.02, 0.04, 0.01]
                },
                balance: {
                    'Total Assets': [0.05, 0.06, 0.04, 0.05, 0.05],
                    'Total Liabilities': [0.04, 0.05, 0.03, 0.04, 0.04],
                    'Total Equity': [0.06, 0.07, 0.05, 0.06, 0.06],
                    'Current Assets': [0.05, 0.06, 0.04, 0.05, 0.05],
                    'Current Liabilities': [0.04, 0.05, 0.03, 0.04, 0.04],
                    'Retained Earnings': [0.07, 0.08, 0.06, 0.07, 0.07]
                },
                cashflow: {
                    'Operating Cash Flow': [0.06, 0.07, 0.05, 0.06, 0.06],
                    'Investing Cash Flow': [-0.02, -0.01, 0.01, -0.02, -0.01],
                    'Financing Cash Flow': [-0.01, -0.02, 0.01, -0.01, -0.02],
                    'Net Change in Cash': [0.08, 0.09, 0.07, 0.08, 0.08],
                    'Free Cash Flow': [0.07, 0.08, 0.06, 0.07, 0.07],
                    'Dividends Paid': [0.03, 0.04, 0.02, 0.03, 0.03]
                }
            };

            // Scenario multipliers (relative to Actual)
            const scenarioMultipliers = {
                'Actual': 1.00,
                'Forecast': 0.96,
                'Budget': 0.93,
                'Worst Case': 0.78,
                'Best Case': 1.12
            };

            // Build data for each table
            Object.keys(TABLES).forEach(tableKey => {
                data[tableKey] = {};
                const items = TABLES[tableKey].lineItems;
                const base = base2025[tableKey];
                const growth = growthRates[tableKey];

                items.forEach(item => {
                    data[tableKey][item] = {};
                    const baseVal = base[item] || 50000;
                    const g = growth[item] || [0.04, 0.04, 0.04, 0.04, 0.04];
                    // Actual values across years
                    const actualVals = {};
                    let val = baseVal;
                    for (let i = 4; i >= 0; i--) {
                        const year = YEARS[i];
                        actualVals[year] = Math.round(val);
                        if (i > 0) {
                            const rate = g[i - 1] || 0.04;
                            val = val / (1 + rate);
                        }
                    }
                    // For each scenario
                    ALL_SCENARIOS.forEach(scenario => {
                        const mult = scenarioMultipliers[scenario] || 1.0;
                        data[tableKey][item][scenario] = {};
                        YEARS.forEach(year => {
                            let baseVal2 = actualVals[year] || 50000;
                            let noise = 0;
                            if (scenario === 'Worst Case') noise = -0.08 * baseVal2 * (1 + Math.random() *
                            0.2);
                            else if (scenario === 'Best Case') noise = 0.10 * baseVal2 * (1 + Math
                            .random() * 0.15);
                            else if (scenario === 'Forecast') noise = 0.02 * baseVal2 * (1 + Math.random() *
                                0.1);
                            else if (scenario === 'Budget') noise = -0.01 * baseVal2 * (1 + Math.random() *
                                0.1);
                            data[tableKey][item][scenario][year] = Math.round((baseVal2 * mult) + noise);
                        });
                    });
                });
            });
            return data;
        }

        const fullData = generateData();

        // ──────────────────────────────────────────────────────────
        //  STATE
        // ──────────────────────────────────────────────────────────

        const state = {
            selectedTable: 'income',
            selectedScenarios: ['Actual', 'Forecast'], // max 3
            baselineScenario: 'Forecast',
            year: '2025',
            lineItem: 'Net income / (loss)', // will be set based on table
            decimals: 2,
            useSeparator: true,
            showVariance: true,
        };

        // ──────────────────────────────────────────────────────────
        //  DOM REFS
        // ──────────────────────────────────────────────────────────

        const $ = id => document.getElementById(id);
        const selectionPage = $('selectionPage');
        const dashboardPage = $('dashboardPage');
        const step1 = $('step1');
        const step2 = $('step2');
        const step1Ind = $('step1Indicator');
        const step2Ind = $('step2Indicator');
        const tableGrid = $('tableGrid');
        const scenarioCheckGrid = $('scenarioCheckGrid');
        const baselineSelect = $('baselineSelect');
        const launchBtn = $('launchBtn');
        const selectionCount = $('selectionCount');
        const optLineItem = $('optLineItem');
        const optYear = $('optYear');
        const optBaseline = $('optBaseline');
        const optDecimals = $('optDecimals');
        const optSeparator = $('optSeparator');
        const optShowVariance = $('optShowVariance');
        const tableHead = $('tableHead');
        const tableBody = $('tableBody');
        const insightGrid = $('insightGrid');
        const trendCanvas = $('trendChart');
        const compareCanvas = $('compareChart');
        const modalCanvas = $('modalChart');
        const activeScenariosList = $('activeScenariosList');
        const scenarioTags = $('scenarioTags');
        const breadcrumbTable = $('breadcrumbTable');
        const breadcrumbYear = $('breadcrumbYear');
        const breadcrumbBaseline = $('breadcrumbBaseline');
        const tableYearLabel = $('tableYearLabel');
        const statusPanel = $('statusPanel');
        const statusPill = $('statusPill');
        const statusList = $('statusList');
        const statusMessage = $('statusMessage');
        const step3Ind = $('step3Indicator');

        let trendChart, compareChart, modalChart;

        // ──────────────────────────────────────────────────────────
        //  HELPERS
        // ──────────────────────────────────────────────────────────

        function fmt(v, decimals, sep) {
            if (v === undefined || v === null) return '—';
            const dec = decimals !== undefined ? decimals : state.decimals;
            const useSep = sep !== undefined ? sep : state.useSeparator;
            const sign = v < 0 ? '-' : '';
            const abs = Math.abs(v);
            const fixed = abs.toFixed(dec);
            if (useSep) {
                const parts = fixed.split('.');
                const intPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                return sign + (parts.length > 1 ? intPart + '.' + parts[1] : intPart);
            }
            return sign + fixed;
        }

        function fmtCurrency(v, decimals, sep) {
            const val = fmt(v, decimals, sep);
            return val === '—' ? val : val;
        }

        function pct(a, b) {
            if (!b || b === 0) return 0;
            return ((a - b) / Math.abs(b)) * 100;
        }

        function varianceClass(val) {
            const abs = Math.abs(val);
            if (abs < 0.5) return 'neutral';
            return val > 0 ? 'positive' : 'negative';
        }

        function varianceSymbol(val) {
            if (Math.abs(val) < 0.5) return '●';
            return val > 0 ? '▲' : '▼';
        }

        function getVal(table, item, scenario, year) {
            return fullData[table]?.[item]?.[scenario]?.[year] ?? 0;
        }

        function getRowData(table, item, year) {
            const row = {};
            ALL_SCENARIOS.forEach(s => {
                row[s] = getVal(table, item, s, year);
            });
            return row;
        }

        function getLineItems(tableKey) {
            return TABLES[tableKey]?.lineItems || [];
        }

        function getTableName(tableKey) {
            return TABLES[tableKey]?.name || tableKey;
        }

        function updateSelectionSteps(activeStep) {
            const isStep1 = activeStep === 1;
            const isStep2 = activeStep === 2;
            const isStep3 = activeStep === 3;
            step1.classList.toggle('active', isStep1);
            step2.classList.toggle('active', isStep2);
            step1Ind.classList.toggle('active', isStep1);
            step2Ind.classList.toggle('active', isStep2);
            step3Ind.classList.toggle('active', isStep3);
        }

        function showRunStatus(show) {
            if (statusPanel) {
                statusPanel.style.display = show ? 'block' : 'none';
            }
        }

        function setRunStatus(status, message) {
            if (statusPill) {
                statusPill.textContent = status;
                statusPill.className = `status-pill ${status.toLowerCase()}`;
            }
            if (statusMessage) {
                statusMessage.textContent = message;
            }
        }

        function renderRunStatus(items) {
            if (!statusList) return;
            statusList.innerHTML = items.map(item => `
                <div class="status-item ${item.state}">
                    <div>
                        <div class="status-item-title">${item.title}</div>
                        <div class="status-item-meta">${item.detail}</div>
                    </div>
                    <div class="status-item-meta">${item.state === 'complete' ? 'Done' : item.state === 'running' ? 'In progress' : 'Queued'}</div>
                </div>
            `).join('');
        }

        function sleep(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }

        async function runScenarioWorkflow(selectedScenarios, baseline, tableName) {
            const tasks = selectedScenarios.map((scenario, index) => ({
                title: `Extract ${scenario}`,
                detail: `Preparing extraction for ${scenario}`,
                state: 'queued',
                scenario,
                index
            }));

            showRunStatus(true);
            renderRunStatus(tasks);
            setRunStatus('Running', 'Extracting the selected forecasting scenario executions...');

            const apiUrl = window.FORECAST_API_URL || '';
            if (apiUrl) {
                try {
                    const response = await fetch(apiUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            table: tableName,
                            baseline,
                            scenarios: selectedScenarios,
                            year: state.year,
                            goal: 'forecasting-scenario-analysis'
                        })
                    });
                    if (!response.ok) throw new Error(`Request failed with ${response.status}`);
                    const payload = await response.json();
                    const jobNames = Array.isArray(payload.jobs) ? payload.jobs : selectedScenarios;
                    const apiTasks = jobNames.map((job, index) => ({
                        title: `Extract ${job}`,
                        detail: payload.message || `Back-end job ${index + 1} received`,
                        state: 'complete',
                        scenario: job,
                        index
                    }));
                    renderRunStatus(apiTasks);
                    setRunStatus('Complete', payload.message || 'The analysis service completed the run.');
                    await sleep(400);
                    return;
                } catch (error) {
                    console.warn('Forecasting API unavailable, falling back to local simulation.', error);
                }
            }

            for (const task of tasks) {
                task.state = 'running';
                task.detail = `Extracting ${task.scenario} from ${getTableName(tableName)}...`;
                renderRunStatus(tasks);
                await sleep(700 + Math.random() * 600);
                task.state = 'complete';
                task.detail = `${task.scenario} extracted and staged for comparison.`;
                renderRunStatus(tasks);
            }

            setRunStatus('Running', 'Merging the extracted scenario outputs and comparing deltas...');
            await sleep(900);
            setRunStatus('Complete', 'Scenario merge complete. Opening the dashboard for outlier and variance analysis.');
            await sleep(600);
        }

        // ──────────────────────────────────────────────────────────
        //  SELECTION PAGE LOGIC
        // ──────────────────────────────────────────────────────────

        // Table selection
        document.querySelectorAll('.table-card').forEach(card => {
            card.addEventListener('click', function() {
                document.querySelectorAll('.table-card').forEach(c => c.classList.remove('selected'));
                this.classList.add('selected');
                state.selectedTable = this.dataset.table;
            });
        });

        // Scenario checkboxes (limit to 3)
        function updateScenarioSelection() {
            const selected = document.querySelectorAll('.scenario-check-card.selected');
            const count = selected.length;
            // Enforce max 3
            if (count > 3) {
                // Deselect the last one (or the one clicked? We'll handle in click)
                // But we'll enforce in click handler
            }
            // Update baseline dropdown options to only selected
            const selScenarios = Array.from(selected).map(el => el.dataset.scenario);
            const baselineSelect = $('baselineSelect');
            // Keep only options that are in selected
            Array.from(baselineSelect.options).forEach(opt => {
                opt.style.display = selScenarios.includes(opt.value) ? '' : 'none';
            });
            // If current baseline not in selected, set to first selected
            if (!selScenarios.includes(baselineSelect.value)) {
                if (selScenarios.length > 0) {
                    baselineSelect.value = selScenarios[0];
                }
            }
            // Update count
            $('selectionCount').textContent = count + ' scenario' + (count > 1 ? 's' : '') + ' selected';
            // Enable/disable launch
            launchBtn.disabled = count === 0;
            launchBtn.style.opacity = count === 0 ? '0.5' : '1';
        }

        document.querySelectorAll('.scenario-check-card').forEach(card => {
            card.addEventListener('click', function() {
                const isSelected = this.classList.contains('selected');
                const selectedCount = document.querySelectorAll('.scenario-check-card.selected').length;
                if (!isSelected && selectedCount >= 3) {
                    alert('You can select up to 3 scenarios.');
                    return;
                }
                this.classList.toggle('selected');
                // If we just deselected, we might need to adjust baseline
                updateScenarioSelection();
            });
        });

        // Select All / Clear All
        function selectAllScenarios(select) {
            const cards = document.querySelectorAll('.scenario-check-card');
            if (select) {
                // Select up to 3: first 3
                cards.forEach((card, idx) => {
                    if (idx < 3) card.classList.add('selected');
                    else card.classList.remove('selected');
                });
            } else {
                cards.forEach(c => c.classList.remove('selected'));
            }
            updateScenarioSelection();
        }

        // Step navigation
        function goToStep2() {
            updateSelectionSteps(2);
            updateScenarioSelection();
        }

        function goToStep1() {
            updateSelectionSteps(1);
        }

        // ──────────────────────────────────────────────────────────
        //  LAUNCH DASHBOARD
        // ──────────────────────────────────────────────────────────

        async function launchDashboard() {
            const selectedScenarios = Array.from(document.querySelectorAll('.scenario-check-card.selected'))
                .map(el => el.dataset.scenario);
            if (selectedScenarios.length === 0) {
                alert('Please select at least one scenario.');
                return;
            }
            const baseline = $('baselineSelect').value;
            if (!selectedScenarios.includes(baseline)) {
                alert('Baseline scenario must be among the selected scenarios.');
                return;
            }

            launchBtn.disabled = true;
            launchBtn.textContent = 'Processing…';
            updateSelectionSteps(3);
            showRunStatus(true);

            // Set state
            state.selectedScenarios = selectedScenarios;
            state.baselineScenario = baseline;
            state.selectedTable = document.querySelector('.table-card.selected').dataset.table;
            // Set default line item to first of table
            const items = getLineItems(state.selectedTable);
            state.lineItem = items[0] || 'Net income / (loss)';

            await runScenarioWorkflow(selectedScenarios, baseline, state.selectedTable);

            launchBtn.disabled = false;
            launchBtn.textContent = 'Run Forecast Comparison →';

            // Update dashboard
            dashboardPage.classList.add('visible');
            selectionPage.classList.add('hidden');

            // Populate options
            populateOptions();
            updateBreadcrumb();
            updateAll();
        }

        // ──────────────────────────────────────────────────────────
        //  POPULATE DASHBOARD OPTIONS
        // ──────────────────────────────────────────────────────────

        function populateOptions() {
            // Line items
            const items = getLineItems(state.selectedTable);
            optLineItem.innerHTML = '';
            items.forEach(item => {
                const opt = document.createElement('option');
                opt.value = item;
                opt.textContent = item;
                if (item === state.lineItem) opt.selected = true;
                optLineItem.appendChild(opt);
            });

            // Baseline dropdown
            optBaseline.innerHTML = '';
            state.selectedScenarios.forEach(sc => {
                const opt = document.createElement('option');
                opt.value = sc;
                opt.textContent = sc;
                if (sc === state.baselineScenario) opt.selected = true;
                optBaseline.appendChild(opt);
            });

            // Year
            optYear.value = state.year;

            // Active scenarios list
            renderActiveScenarios();

            // Scenario tags in top bar
            renderScenarioTags();
        }

        function renderActiveScenarios() {
            let html = '';
            state.selectedScenarios.forEach(sc => {
                const isBase = sc === state.baselineScenario;
                html += `<span class="scenario-tag-badge ${sc.toLowerCase().replace(' ','-')} ${isBase ? 'baseline-tag' : ''}" 
                              style="${isBase ? 'font-weight:600;' : ''}">
                              ${sc} ${isBase ? '★' : ''}
                          </span>`;
            });
            activeScenariosList.innerHTML = html;
        }

        function renderScenarioTags() {
            let html = '';
            state.selectedScenarios.forEach(sc => {
                const isBase = sc === state.baselineScenario;
                html += `<span class="tag ${isBase ? 'baseline' : ''}">${sc} ${isBase ? '(baseline)' : ''}</span>`;
            });
            scenarioTags.innerHTML = html;
        }

        function updateBreadcrumb() {
            breadcrumbTable.textContent = getTableName(state.selectedTable);
            breadcrumbYear.textContent = state.year;
            breadcrumbBaseline.textContent = state.baselineScenario;
            tableYearLabel.textContent = `(${state.year})`;
        }

        // ──────────────────────────────────────────────────────────
        //  RENDER: KPI
        // ──────────────────────────────────────────────────────────

        function renderKPI() {
            const year = state.year;
            const table = state.selectedTable;
            const item = state.lineItem;
            const baseline = state.baselineScenario;
            const scenarios = state.selectedScenarios;

            // Get values for all selected scenarios
            const vals = {};
            scenarios.forEach(sc => {
                vals[sc] = getVal(table, item, sc, year);
            });

            const baselineVal = vals[baseline] || 0;
            let maxVal = -Infinity,
                maxSc = '';
            let minVal = Infinity,
                minSc = '';
            scenarios.forEach(sc => {
                const v = vals[sc] || 0;
                if (v > maxVal) { maxVal = v;
                    maxSc = sc; }
                if (v < minVal) { minVal = v;
                    minSc = sc; }
            });

            const spread = maxVal - minVal;

            const d = state.decimals;
            const sep = state.useSeparator;

            $('kpiBaseline').textContent = fmtCurrency(baselineVal, d, sep);
            $('kpiBaselineLabel').textContent = `${baseline} (baseline)`;
            $('kpiBaselineLabel').className = `change neutral`;

            $('kpiHighest').textContent = fmtCurrency(maxVal, d, sep);
            $('kpiHighestLabel').textContent = `▲ ${maxSc}`;
            $('kpiHighestLabel').className = `change positive`;

            $('kpiLowest').textContent = fmtCurrency(minVal, d, sep);
            $('kpiLowestLabel').textContent = `▼ ${minSc}`;
            $('kpiLowestLabel').className = `change negative`;

            $('kpiSpread').textContent = fmtCurrency(spread, d, sep);
            $('kpiSpreadLabel').textContent = 'range';
            $('kpiSpreadLabel').className = `change neutral`;
        }

        // ──────────────────────────────────────────────────────────
        //  RENDER: TABLE
        // ──────────────────────────────────────────────────────────

        function renderTable() {
            const year = state.year;
            const table = state.selectedTable;
            const baseline = state.baselineScenario;
            const scenarios = state.selectedScenarios;
            const d = state.decimals;
            const sep = state.useSeparator;
            const showVar = state.showVariance;

            // Build table head
            let headHtml = `<tr>
                                <th style="min-width:160px;">Line Item</th>`;
            scenarios.forEach(sc => {
                headHtml += `<th class="num">${sc} ${sc === baseline ? '★' : ''}</th>`;
            });
            if (showVar) {
                headHtml += `<th class="num" style="min-width:90px;">Variance vs ${baseline}</th>`;
            }
            headHtml += `</tr>`;
            tableHead.innerHTML = headHtml;

            // Build body
            const items = getLineItems(table);
            let bodyHtml = '';
            let maxVariance = -Infinity;
            let minVariance = Infinity;
            let highlightRow = '';

            // First pass to find max/min variance
            const varianceData = {};
            items.forEach(item => {
                const row = getRowData(table, item, year);
                const baselineVal = row[baseline] || 0;
                const varPct = pct(row[baseline] || 0, baselineVal); // Actually compare each scenario to baseline
                // We'll compute variance for each scenario vs baseline
                let maxVar = -Infinity,
                    minVar = Infinity;
                scenarios.forEach(sc => {
                    const val = row[sc] || 0;
                    const v = pct(val, baselineVal);
                    if (v > maxVar) maxVar = v;
                    if (v < minVar) minVar = v;
                });
                varianceData[item] = { maxVar, minVar };
                if (maxVar > maxVariance) maxVariance = maxVar;
                if (minVar < minVariance) minVariance = minVar;
            });

            items.forEach(item => {
                const row = getRowData(table, item, year);
                const baselineVal = row[baseline] || 0;
                let varPct = 0;
                let varClass = 'neutral';
                let varSymbol = '●';
                let varDisplay = '—';
                if (baselineVal !== 0) {
                    // Use first scenario as reference? Actually we compare each scenario to baseline, but we show overall variance for the line item.
                    // We'll pick the scenario with largest absolute variance?
                    // Or show the variance of the baseline vs itself (0). Instead, we show the max variance across scenarios vs baseline.
                    let maxAbsVar = 0;
                    let maxVarSc = '';
                    scenarios.forEach(sc => {
                        const val = row[sc] || 0;
                        const v = pct(val, baselineVal);
                        if (Math.abs(v) > Math.abs(maxAbsVar)) {
                            maxAbsVar = v;
                            maxVarSc = sc;
                        }
                    });
                    varPct = maxAbsVar;
                    varClass = varianceClass(varPct);
                    varSymbol = varianceSymbol(varPct);
                    varDisplay = `${varSymbol} ${Math.abs(varPct).toFixed(1)}%`;
                }

                // Check if this row has high variance (top/bottom 20%) for highlighting
                const isHighlight = (varianceData[item] && 
                    (varianceData[item].maxVar >= maxVariance * 0.8 || 
                     varianceData[item].minVar <= minVariance * 0.8));

                bodyHtml += `<tr class="${isHighlight ? 'highlight-row' : ''}" onclick="openDrill('${item}')" style="cursor:pointer;">`;
                bodyHtml += `<td>${item} <span class="drill-icon" title="Drill down">↕</span></td>`;
                scenarios.forEach(sc => {
                    const val = row[sc] || 0;
                    bodyHtml += `<td class="num">${fmtCurrency(val, d, sep)}<span class="sub">${sc}</span></td>`;
                });
                if (showVar) {
                    bodyHtml += `<td class="num">
                                    <span class="variance-badge ${varClass}">${varDisplay}</span>
                                    <span class="sub">vs ${baseline}</span>
                                </td>`;
                }
                bodyHtml += `</tr>`;
            });

            tableBody.innerHTML = bodyHtml;
            tableYearLabel.textContent = `(${year})`;
        }

        // ──────────────────────────────────────────────────────────
        //  RENDER: CHARTS
        // ──────────────────────────────────────────────────────────

        function renderTrendChart() {
            const table = state.selectedTable;
            const item = state.lineItem;
            const scenarios = state.selectedScenarios;
            const ctx = trendCanvas.getContext('2d');
            if (trendChart) trendChart.destroy();

            const colors = ['#0f1a2b', '#3E8635', '#BC7100', '#BE0611', '#1a6b3c'];
            const datasets = scenarios.map((sc, i) => ({
                label: sc,
                data: YEARS.map(y => getVal(table, item, sc, y)),
                borderColor: colors[i % colors.length],
                backgroundColor: colors[i % colors.length] + '22',
                borderWidth: 2,
                pointRadius: 3,
                pointBorderColor: '#fff',
                pointBorderWidth: 1,
                tension: 0.2,
                fill: false,
            }));

            trendChart = new Chart(ctx, {
                type: 'line',
                data: { labels: YEARS, datasets },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'top', labels: { boxWidth: 12, padding: 10, font: { size: 10 } } },
                        tooltip: { callbacks: { label: ctx => `${ctx.dataset.label}: $${ctx.parsed.y.toLocaleString()}` } }
                    },
                    scales: {
                        y: {
                            ticks: { callback: v => '$' + (v / 1000).toFixed(0) + 'k' },
                            grid: { color: 'rgba(0,0,0,0.04)' }
                        },
                        x: { grid: { display: false } }
                    }
                }
            });
            $('trendSub').textContent = item;
        }

        function renderCompareChart() {
            const table = state.selectedTable;
            const item = state.lineItem;
            const year = state.year;
            const scenarios = state.selectedScenarios;
            const ctx = compareCanvas.getContext('2d');
            if (compareChart) compareChart.destroy();

            const colors = ['#0f1a2b', '#3E8635', '#BC7100', '#BE0611', '#1a6b3c'];
            const vals = scenarios.map(sc => getVal(table, item, sc, year));

            compareChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: scenarios,
                    datasets: [{
                        label: `${item} · ${year}`,
                        data: vals,
                        backgroundColor: colors.slice(0, scenarios.length).map(c => c + 'CC'),
                        borderColor: colors.slice(0, scenarios.length),
                        borderWidth: 1.5,
                        borderRadius: 4,
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: { callbacks: { label: ctx => '$' + ctx.parsed.y.toLocaleString() } }
                    },
                    scales: {
                        y: {
                            ticks: { callback: v => '$' + (v / 1000).toFixed(0) + 'k' },
                            grid: { color: 'rgba(0,0,0,0.04)' }
                        },
                        x: { grid: { display: false } }
                    }
                }
            });
            $('compareSub').textContent = `${year} · ${item}`;
        }

        // ──────────────────────────────────────────────────────────
        //  RENDER: AI INSIGHTS (key differences)
        // ──────────────────────────────────────────────────────────

        function renderAI() {
            const table = state.selectedTable;
            const year = state.year;
            const baseline = state.baselineScenario;
            const scenarios = state.selectedScenarios;
            const items = getLineItems(table);

            // For each item, compute variance vs baseline for each scenario, find largest positive and negative
            let maxPos = -Infinity,
                maxPosItem = '',
                maxPosSc = '';
            let maxNeg = Infinity,
                maxNegItem = '',
                maxNegSc = '';
            let totalBaseline = 0;
            let totalMax = 0;

            items.forEach(item => {
                const row = getRowData(table, item, year);
                const baselineVal = row[baseline] || 0;
                totalBaseline += Math.abs(baselineVal);
                scenarios.forEach(sc => {
                    if (sc === baseline) return;
                    const val = row[sc] || 0;
                    const varPct = pct(val, baselineVal);
                    if (varPct > maxPos) { maxPos = varPct;
                        maxPosItem = item;
                        maxPosSc = sc; }
                    if (varPct < maxNeg) { maxNeg = varPct;
                        maxNegItem = item;
                        maxNegSc = sc; }
                });
            });

            const insights = [];
            if (maxPosItem) {
                insights.push({
                    title: `Largest upside: ${maxPosItem}`,
                    desc: `${maxPosSc} is ${maxPos.toFixed(1)}% above ${baseline} ($${Math.abs(getVal(table, maxPosItem, maxPosSc, year) - getVal(table, maxPosItem, baseline, year)).toLocaleString()})`,
                    type: 'positive'
                });
            }
            if (maxNegItem) {
                insights.push({
                    title: `Largest downside: ${maxNegItem}`,
                    desc: `${maxNegSc} is ${Math.abs(maxNeg).toFixed(1)}% below ${baseline} ($${Math.abs(getVal(table, maxNegItem, maxNegSc, year) - getVal(table, maxNegItem, baseline, year)).toLocaleString()})`,
                    type: 'danger'
                });
            }
            // Spread
            const spread = items.map(item => {
                const vals = scenarios.map(sc => getVal(table, item, sc, year));
                return Math.max(...vals) - Math.min(...vals);
            });
            const maxSpread = Math.max(...spread);
            const maxSpreadItem = items[spread.indexOf(maxSpread)];
            insights.push({
                title: `Widest range: ${maxSpreadItem}`,
                desc: `Spread of $${maxSpread.toLocaleString()} across scenarios`,
                type: 'warning'
            });

            // Baseline performance
            const baselineTotal = items.reduce((sum, item) => sum + getVal(table, item, baseline, year), 0);
            insights.push({
                title: `Baseline total (${baseline})`,
                desc: `Sum of selected line items: $${baselineTotal.toLocaleString()}`,
                type: 'success'
            });

            let html = '';
            insights.forEach(ins => {
                const map = { positive: 'success', danger: 'danger', warning: 'warning', success: 'success' };
                const cls = map[ins.type] || 'success';
                html += `
                    <div class="insight-item ${cls}">
                        <div class="title">${ins.title}</div>
                        <div class="desc">${ins.desc}</div>
                    </div>
                `;
            });
            insightGrid.innerHTML = html;
            $('aiTimestamp').textContent = `Updated ${new Date().toLocaleTimeString()}`;
        }

        // ──────────────────────────────────────────────────────────
        //  DRILL MODAL
        // ──────────────────────────────────────────────────────────

        function openDrill(item) {
            const table = state.selectedTable;
            const scenarios = state.selectedScenarios;
            $('modalItemName').textContent = item;

            // Update modal table headers dynamically
            const headMap = {
                'modalHeadActual': 'Actual',
                'modalHeadForecast': 'Forecast',
                'modalHeadBudget': 'Budget',
                'modalHeadWorst': 'Worst',
                'modalHeadBest': 'Best'
            };
            // Show only selected scenarios
            const allHeads = ['modalHeadActual', 'modalHeadForecast', 'modalHeadBudget', 'modalHeadWorst', 'modalHeadBest'];
            allHeads.forEach(id => {
                const el = $(id);
                const sc = el.textContent;
                el.style.display = scenarios.includes(sc) ? '' : 'none';
            });

            // Build table rows
            let html = '';
            YEARS.forEach(year => {
                html += `<tr><td><strong>${year}</strong></td>`;
                ALL_SCENARIOS.forEach(sc => {
                    if (scenarios.includes(sc)) {
                        const val = getVal(table, item, sc, year);
                        html += `<td class="num">${fmtCurrency(val, state.decimals, state.useSeparator)}</td>`;
                    }
                });
                html += `</tr>`;
            });
            $('modalTableBody').innerHTML = html;

            // Chart
            const ctx = modalCanvas.getContext('2d');
            if (modalChart) modalChart.destroy();

            const colors = ['#0f1a2b', '#3E8635', '#BC7100', '#BE0611', '#1a6b3c'];
            const datasets = scenarios.map((sc, i) => ({
                label: sc,
                data: YEARS.map(y => getVal(table, item, sc, y)),
                borderColor: colors[i % colors.length],
                backgroundColor: colors[i % colors.length] + '22',
                borderWidth: 2,
                pointRadius: 3,
                tension: 0.15,
                fill: false,
            }));

            modalChart = new Chart(ctx, {
                type: 'line',
                data: { labels: YEARS, datasets },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'top', labels: { boxWidth: 12, padding: 8, font: { size: 10 } } },
                        tooltip: { callbacks: { label: ctx => `${ctx.dataset.label}: $${ctx.parsed.y.toLocaleString()}` } }
                    },
                    scales: {
                        y: { ticks: { callback: v => '$' + (v / 1000).toFixed(0) + 'k' }, grid: { color: 'rgba(0,0,0,0.04)' } },
                        x: { grid: { display: false } }
                    }
                }
            });

            $('modalNote').textContent = `5‑year trend · ${item} · selected scenarios`;
            $('drillModal').classList.add('active');
        }

        function closeModal() {
            $('drillModal').classList.remove('active');
            if (modalChart) { modalChart.destroy();
                modalChart = null; }
        }

        $('drillModal').addEventListener('click', function(e) {
            if (e.target === this) closeModal();
        });

        // ──────────────────────────────────────────────────────────
        //  EXPORT CSV
        // ──────────────────────────────────────────────────────────

        function exportCSV() {
            const table = state.selectedTable;
            const year = state.year;
            const scenarios = state.selectedScenarios;
            const items = getLineItems(table);
            let csv = 'Line Item,' + scenarios.join(',') + '\n';
            items.forEach(item => {
                const row = getRowData(table, item, year);
                csv += item + ',' + scenarios.map(sc => row[sc] || 0).join(',') + '\n';
            });
            const blob = new Blob([csv], { type: 'text/csv' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = `comparison_${getTableName(table)}_${year}.csv`;
            link.click();
        }

        // ──────────────────────────────────────────────────────────
        //  RESET FILTERS (dashboard)
        // ──────────────────────────────────────────────────────────

        function resetFilters() {
            // Reset to first line item, first year
            const items = getLineItems(state.selectedTable);
            optLineItem.value = items[0] || '';
            optYear.value = '2025';
            optBaseline.value = state.baselineScenario;
            optDecimals.value = '2';
            optSeparator.checked = true;
            optShowVariance.checked = true;
            state.lineItem = optLineItem.value;
            state.year = optYear.value;
            state.baselineScenario = optBaseline.value;
            state.decimals = 2;
            state.useSeparator = true;
            state.showVariance = true;
            updateAll();
        }

        // ──────────────────────────────────────────────────────────
        //  UPDATE ALL
        // ──────────────────────────────────────────────────────────

        function updateAll() {
            state.lineItem = optLineItem.value;
            state.year = optYear.value;
            state.baselineScenario = optBaseline.value;
            state.decimals = parseInt(optDecimals.value) || 0;
            state.useSeparator = optSeparator.checked;
            state.showVariance = optShowVariance.checked;

            updateBreadcrumb();
            renderKPI();
            renderTable();
            renderTrendChart();
            renderCompareChart();
            renderAI();
            renderActiveScenarios();
            renderScenarioTags();
        }

        // ──────────────────────────────────────────────────────────
        //  REFRESH / NAVIGATION
        // ──────────────────────────────────────────────────────────

        function refreshAll() {
            updateAll();
            $('aiTimestamp').textContent = `Updated ${new Date().toLocaleTimeString()}`;
        }

        function goBackToSelection() {
            dashboardPage.classList.remove('visible');
            selectionPage.classList.remove('hidden');
            // Reset steps to step 2 (scenarios) for convenience
            goToStep2();
        }

        function switchTool(tool) {
            document.querySelectorAll('.toolkit .nav-item').forEach(el => el.classList.remove('active'));
            const items = document.querySelectorAll('.toolkit .nav-item');
            const map = { 'dashboard': 0, 'scenarios': 1, 'compare': 2 };
            const idx = map[tool] || 0;
            if (items[idx]) items[idx].classList.add('active');
            if (tool === 'scenarios') {
                goBackToSelection();
            } else if (tool === 'compare') {
                alert('Compare view: select multiple scenarios to compare side by side.');
            }
        }

        // ──────────────────────────────────────────────────────────
        //  EVENT LISTENERS (dashboard options)
        // ──────────────────────────────────────────────────────────

        optLineItem.addEventListener('change', updateAll);
        optYear.addEventListener('change', updateAll);
        optBaseline.addEventListener('change', updateAll);
        optDecimals.addEventListener('change', updateAll);
        optSeparator.addEventListener('change', updateAll);
        optShowVariance.addEventListener('change', updateAll);

        // ──────────────────────────────────────────────────────────
        //  RESIZE CHARTS
        // ──────────────────────────────────────────────────────────

        let resizeTimer;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(() => {
                if (trendChart) trendChart.resize();
                if (compareChart) compareChart.resize();
                if (modalChart) modalChart.resize();
            }, 200);
        });

        // ──────────────────────────────────────────────────────────
        //  KEYBOARD SHORTCUT
        // ──────────────────────────────────────────────────────────

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeModal();
        });

        // ──────────────────────────────────────────────────────────
        //  INIT
        // ──────────────────────────────────────────────────────────

        // Start with selection page visible
        selectionPage.classList.remove('hidden');
        dashboardPage.classList.remove('visible');
        // Default: step 1 active
        goToStep1();
        // Set default selected scenarios (first two)
        document.querySelectorAll('.scenario-check-card').forEach((card, idx) => {
            if (idx < 2) card.classList.add('selected');
        });
        updateScenarioSelection();

        console.log('✅ Financial Scenario Dashboard loaded.');
        console.log('💡 Select a table and up to 3 scenarios, then launch the dashboard.');
        console.log('💡 Click any table row to drill into 5‑year details.');
